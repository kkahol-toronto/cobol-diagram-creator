# MermaidDiagramRenderer

A Python tool to generate both static SVG and interactive HTML flow diagrams from Mermaid definitions embedded in Markdown files. Designed for batch processing of COBOL control flow diagrams or any Mermaid-based documentation.

## Features
- Extracts Mermaid diagrams from Markdown files (```mermaid code blocks)
- Generates static SVG diagrams using Mermaid CLI
- Generates interactive, scrollable, color-coded HTML diagrams with expand/collapse (Pyvis/vis.js)
- Batch processes all `_control_flow.md` files in subfolders

## Installation

### 1. Clone the repository
```sh
git clone <your-repo-url>
cd <your-repo-directory>
```

### 2. Set up Python environment
```sh
python3 -m venv venv
source venv/bin/activate
```

### 3. Install Python dependencies
```sh
pip install -r requirements.txt
```

### 4. Install Node.js and Mermaid CLI
- **Node.js:** [Download & install](https://nodejs.org/)
- **Mermaid CLI:**
```sh
npm install -g @mermaid-js/mermaid-cli
```
- **Playwright (for Mermaid CLI rendering):**
```sh
npx playwright install chromium
```

## Usage

### Batch mode (recommended)
Process all `_control_flow.md` files in subfolders of `Kanav_diagram`:
```sh
python render_diagram.py
```
- For each file, outputs:
  - `EXWWB910.svg` (static SVG)
  - `EXWWB910_interactive.html` (interactive HTML)

### Single file mode (customize in code)
You can modify the script to process a single file:
```python
renderer = MermaidDiagramRenderer('Kanav_diagram/EXWWB910/EXWWB910_control_flow.md')
renderer.build_svg()
renderer.build_interactive()
```

## Output
- SVG and HTML files are saved in the same directory as the input Markdown file.

## Troubleshooting
- **UnknownDiagramError:** Ensure your Markdown file contains a valid ```mermaid code block.
- **mmdc not found:** Make sure `@mermaid-js/mermaid-cli` is installed globally and on your PATH.
- **Playwright errors:** Run `npx playwright install chromium` after installing Mermaid CLI.
- **Pyvis/vis.js errors:** Ensure all Python dependencies are installed.

## License
This is intellectual property of Ford